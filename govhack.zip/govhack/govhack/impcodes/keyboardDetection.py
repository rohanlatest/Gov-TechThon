import keyboard
while True:
    if keyboard.is_pressed('ctrl'):
        print("ctrl key is pressed")
        break
    if keyboard.is_pressed('alt'):
        print("alt key  is pressed")
        break
    if keyboard.is_pressed('shift'):
        print("shift key is pressed")
        break
    if keyboard.is_pressed('up'):
        print("up key is pressed")
        break
    if keyboard.is_pressed('down'):
        print("down key is pressed")
        break
    if keyboard.is_pressed('left'):
        print("left key is pressed")
        break
    if keyboard.is_pressed('right'):
        print("right key  is pressed")
        break



