import speech_recognition as sr
import pyaudio
r = sr.Recognizer()

with sr.Microphone() as source:
    print('Speak Anything :')
    audio = r.listen(source)

    try:
        text = sr.recognize_google(audio)
        print('you said : {}'.format(text))
    except Exception:
        print('sorry could not recognize your voice')
