import sounddevice as sd
import numpy as np
duration =200

def print_sound(indata , outdata , frames , time , status):
    volume_norm = np.linalg.norm(indata)*10
    print("|" * int(volume_norm))
    stream = sd.InputStream(callback=audio_callback)
    with stream:
        sd.sleep(duration * 1000)
