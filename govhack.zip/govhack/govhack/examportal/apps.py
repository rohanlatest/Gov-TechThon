from django.apps import AppConfig


class ExamportalConfig(AppConfig):
    name = 'examportal'
